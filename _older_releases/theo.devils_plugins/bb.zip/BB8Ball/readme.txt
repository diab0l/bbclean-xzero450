-------------------------------------------------------------------------
-                                                                       - 
-          *****   *****    ***   *****          *  *                   -
-          *    *  *    *  *   *  *    *         *  *                   -   
-          *    *  *    *  *   *  *    *   ***   *  *                   -   
-          *    *  *    *  *   *  *    *  *   *  *  *                   -   
-          ******  ******   ***   ******      *  *  *                   -   
-          *    *  *    *  *   *  *    *   ****  *  *                   -   
-          *    *  *    *  *   *  *    *  *   *  *  *                   -   
-          *    *  *    *  *   *  *    *  *  **  *  *                   -   
-          *****   *****    ***   *****    ** *  *  *                   -
-                                                                       -   
-                         BB8Ball 1.1 beta 2                            -
-------------------------------------------------------------------------
									
8Ball this is..... and now its a little more....			
				
-------------------------------------------------------------------------

known issues:

 - nothing i know about

-------------------------------------------------------------------------

controls:

 - ctrl + left click & drag: move
 - ctrl + right click: open menu
 - left click - gives prediction 
 - right click - gives fortune

 - enter - presses OK in the message
 - space - presses One More in the message

-------------------------------------------------------------------------

some comments:

 - if you wont to have other fortunes, just change the fortune.rc file
   every fortune has to start with xxx: where xxx is a 3 digit number
   so the max count of fortunes in one file is 999.....
 - currently if you have less than 1000 fortunes in the file, if the
   bb8ball selects a number which isnt in the file, you will have
   a message "Nothing foud, maybe the file isnt there?"....
 - actually the file can consist of anithing you wont, (fortunes, jokes,
   quotes and what so ever), just give each line a 3 digit number
   and where you wont to heave new lines insert \n .... and thats all 
   folks

-------------------------------------------------------------------------

bro@ms:
 
 - @BB8BallPredict - gives prediction
 - @BB8BallFortune - gives a fortune
 - @BB8BallHideMode - hides the plugin window (only way to unhide is
                      using this broam or by editing .rc and reconfigure)

-------------------------------------------------------------------------

version history:

BB8Ball 1.1 beta 2 - 27/8/2004

 - added the give fortune setting
 - created a fortune file with 1000 fortunes
 - made some changes in the message box drawing 
 - the messagebox now fits the text that is drawn
 - select if you wont the message to be centered on the screen
   or use custom possition
 - the fortune messagebox has seccond button (one more)
 - added keyboard controls, enter will press OK, space will press ONE MORE
 - right click on bb8ball will give fortune, ctrl+rclick will show menu

BB8Ball 1.1 beta 1 - 22/8/2004

 - first plugin with bbstyle messagebox 

BB8Ball 1.0 - ?/?/2004
  
 - for info about this plugin read the bb8ball 1.0 readme

--------------------------------------------------------------------------

Created by Miroslav Petrasko [Theo] (theo.devil@gmx.net)

                                              all rights reserved... C2004

--------------------------------------------------------------------------

BB8Ball  IS  PROVIDED  "AS IS"  WITHOUT  WARRANTY  OF ANY KIND. THE AUTHOR
DISCLAIMS  ALL  WARRANTIES,  EITHER  EXPRESS  OR  IMPLIED,  INCLUDING  THE 
WARRANTIES  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. IN NO
EVENT  SHALL  THE  AUTHOR  OR  ITS  SUPPLIERS  BE  LIABLE  FOR ANY DAMAGES 
WHATSOEVER  INCLUDING  DIRECT,  INDIRECT,  INCIDENTAL, CONSEQUENTIAL, LOSS
OF BUSINESS  PROFITS  OR  SPECIAL  DAMAGES,  EVEN  IF  THE  AUTHOR  OR ITS 
SUPPLIERS  HAVE  BEEN   ADVISED  OF   THE  POSSIBILITY  OF  SUCH  DAMAGES.


--------------------------------------------------------------------------
-                                                                        -
-         *  *                 *              *          *               -        
-         ** ***   **   **     ***   **   ******     *** *  *            -        
-         *  *  * *  * *  *    *  * *  * *    *     *    * *             -        
-         *  *  * **** *  *    *  * *  *  **  *      **  ***             -        
-         *  *  * *    *  *    *  * *  *    * *        * * *             -        
-         ** *  *  ***  **   * *  *  **  ***  **  * ***  *  *            - 
-                                                                        -
--------------------------------------------------------------------------