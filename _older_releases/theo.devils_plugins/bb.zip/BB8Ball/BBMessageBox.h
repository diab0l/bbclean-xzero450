#ifndef __BB8BALL_H
#define __BB8BALL_H


LRESULT CALLBACK MesProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);


//=============================================================

#endif
