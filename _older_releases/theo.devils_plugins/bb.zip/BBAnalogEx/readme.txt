-------------------------------------------------------------------------
-									-
-                                                                       -    
-   *****   *****     *                  *                ******        -  
-   *    *  *    *   * *                 *                *             -  
-   *    *  *    *   * *   * **    ***   *   ***    ** *  *      *   *  -  
-   *    *  *    *   * *   **  *  *   *  *  *   *  *  **  *       * *   -  
-   ******  ******  *   *  *   *      *  *  *   *  *   *  ******  * *   -  
-   *    *  *    *  *****  *   *   ****  *  *   *  *   *  *        *    -  
-   *    *  *    *  *   *  *   *  *   *  *  *   *  *   *  *       * *   -  
-   *    *  *    * *     * *   *  *  **  *  *   *  *  **  *       * *   -  
-   *****   *****  *     * *   *   ** *  *   ***    ** *  ****** *   *  -  
-                                                      *                -  
-                                                  ****                 -        -                                                                       -   
-                         BBAnalogEx 1.5 beta 2                         -
-------------------------------------------------------------------------
									
I decided to split bbanalogex into two plugins containing the analog
and the digital clock. this is a beta of the analog clock...			
				
-------------------------------------------------------------------------

known issues:

 - nothing i know about

-------------------------------------------------------------------------

controls:

 - ctrl + left click & drag: move
 - ctrl + right click: open menu
 - left click - opens the windows clock dialog 

-------------------------------------------------------------------------

some comments:

 - not everithing works perfect right now but maybe later.... :-)
 - bbanalogex.hands.width: 4221
   the first number is hour hand width, the seccond is minute, the third
   is second and the last is circle width (min 1 - max 9)
 - bbanalogex.hands.length: 677647
   first two numbers are hour length, second two are minute length
   and the last two are second length (min 01 - max 99)

-------------------------------------------------------------------------

version history:

BBAnalogEx 1.5 beta 1 - 25/08/2004

 - added some configuration setting
 - show/hide circle
 - set the hands length, width
 - set the hands color
 - set the circle color,width

BBAnalogEx 1.5 beta 1 - 21/08/2004

 - removed temporelly many things (some will be back some not)
 - second draw mod (circles)
 - the main code is not based on analogex 1.4 but on the digitalex 1.0
   so it should be more stable as the 1.4 version

BBAnalogEx 1.4 - ?/?/2004
  
 - for info about this plugin read the bbanalogex 1.4 readme

--------------------------------------------------------------------------

Created by Miroslav Petrasko [Theo] (theo.devil@gmx.net)

                                              all rights reserved... C2004

--------------------------------------------------------------------------

BBAnalogEx  IS PROVIDED  "AS IS"  WITHOUT WARRANTY OF ANY KIND. THE AUTHOR
DISCLAIMS  ALL  WARRANTIES,  EITHER  EXPRESS  OR  IMPLIED,  INCLUDING  THE 
WARRANTIES  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. IN NO
EVENT  SHALL  THE  AUTHOR  OR  ITS  SUPPLIERS  BE  LIABLE  FOR ANY DAMAGES 
WHATSOEVER  INCLUDING  DIRECT,  INDIRECT,  INCIDENTAL, CONSEQUENTIAL, LOSS
OF BUSINESS  PROFITS  OR  SPECIAL  DAMAGES,  EVEN  IF  THE  AUTHOR  OR ITS 
SUPPLIERS  HAVE  BEEN   ADVISED  OF   THE  POSSIBILITY  OF  SUCH  DAMAGES.


--------------------------------------------------------------------------
-                                                                        -
-         *  *                 *              *          *               -        
-         ** ***   **   **     ***   **   ******     *** *  *            -        
-         *  *  * *  * *  *    *  * *  * *    *     *    * *             -        
-         *  *  * **** *  *    *  * *  *  **  *      **  ***             -        
-         *  *  * *    *  *    *  * *  *    * *        * * *             -        
-         ** *  *  ***  **   * *  *  **  ***  **  * ***  *  *            - 
-                                                                        -
--------------------------------------------------------------------------