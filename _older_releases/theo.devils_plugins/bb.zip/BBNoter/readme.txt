-------------------------------------------------------------------------
-                                                                       -
-     ******   ******   *       *                       *   **          -  
-     *     *  *     *  **     **                          *            -  
-     *     *  *     *  **     **                          *            -  
-     *     *  *     *  * *   * *   ***    ** *  * **   * *** *   *     -  
-     ******   ******   * *   * *  *   *  *  **  **  *  *  *  *   *     -  
-     *     *  *     *  *  * *  *      *  *   *  *   *  *  *   * *      -  
-     *     *  *     *  *  * *  *   ****  *   *  *   *  *  *   * *      -  
-     *     *  *     *  *  * *  *  *   *  *   *  *   *  *  *   * *      -  
-     *     *  *     *  *   *   *  *  **  *  **  *   *  *  *    *       -  
-     ******   ******   *   *   *   ** *   ** *  *   *  *  *    *       -  
-                                             *                 *       -  
-                                         *   *                 *       -  
-                                          ***                **        -  
-                                                                       -
-                              BBMagnify 1.0                            -
-------------------------------------------------------------------------
									
BBMagnify is a magnifier plugin... and it shows the cursor position				

I wanted the picture in my SideBar to do something so i created this...									
-------------------------------------------------------------------------

known issues:

 - nothing i know about...

-------------------------------------------------------------------------

controls:

 - left click: start/stop magnifying
 - ctrl + left click & drag: move
 - ctrl + right click: open menu

-------------------------------------------------------------------------

some comments:
	
 - the ratio can be other then the 1,2,4,8,16,32, just change the
   ratio in the rc file ... min is 1
 - i dont really know if this works on win9x systems... i couldnt really 
   test it
 - the text is drawn using the color that is set to the text in the used 
   style setting (hopefully someone understands this line... :-)) 
 
-------------------------------------------------------------------------

future plans for this plugin:

 - right now there is a timer which controls the redrawing... i wont to 
   redraw it as a result of mouse move...

-------------------------------------------------------------------------

version history:

BBMagnify 1.0 - 06/08/2004

 - first version

--------------------------------------------------------------------------

Created by Miroslav Petrasko [Theo] (theo.devil@gmx.net)

                                              all rights reserved... C2004

BBMagnify  IS  PROVIDED  "AS IS"  WITHOUT WARRANTY OF ANY KIND. THE AUTHOR
DISCLAIMS  ALL  WARRANTIES,  EITHER  EXPRESS  OR  IMPLIED,  INCLUDING  THE 
WARRANTIES  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. IN NO
EVENT  SHALL  THE  AUTHOR  OR  ITS  SUPPLIERS  BE  LIABLE  FOR ANY DAMAGES 
WHATSOEVER  INCLUDING  DIRECT,  INDIRECT,  INCIDENTAL, CONSEQUENTIAL, LOSS
OF BUSINESS  PROFITS  OR  SPECIAL  DAMAGES,  EVEN  IF  THE  AUTHOR  OR ITS 
SUPPLIERS  HAVE  BEEN   ADVISED  OF   THE  POSSIBILITY  OF  SUCH  DAMAGES.


--------------------------------------------------------------------------
-                                                                        -
-         *  *                 *              *          *               -        
-         ** ***   **   **     ***   **   ******     *** *  *            -        
-         *  *  * *  * *  *    *  * *  * *    *     *    * *             -        
-         *  *  * **** *  *    *  * *  *  **  *      **  ***             -        
-         *  *  * *    *  *    *  * *  *    * *        * * *             -        
-         ** *  *  ***  **   * *  *  **  ***  **  * ***  *  *            - 
-                                                                        -
--------------------------------------------------------------------------