-------------------------------------------------------------------------   
-                         BBRSS 1.0 beta 1                              -
-------------------------------------------------------------------------
									
a simple rss plugin.. not all feeds work perfect.. 

-------------------------------------------------------------------------

known issues:

 - the results are very rss feed depending.. 

-------------------------------------------------------------------------

controls:

 - ctrl + left click & drag: move
 - ctrl + right click: open menu
 - left click - opens the windows url adress 

-------------------------------------------------------------------------

some comments:

 - not everithing works perfect right now but maybe later.... :-) 
 - the alarms.rc holds ten favorite rss feeds which you can change 
   between
 - ns.rc is for temporary storing of the rss feed

-------------------------------------------------------------------------   

future plans for this plugin:

 - create a better rss parser 

-------------------------------------------------------------------------

version history:

BBRSS 1.0 beta 1 - 08/12/2004
  
 - first version

--------------------------------------------------------------------------

Created by Miroslav Petrasko [Theo] (theo.devil@gmx.net)

                                              all rights reserved... C2004

--------------------------------------------------------------------------

BBRSS IS  PROVIDED   "AS IS"   WITHOUT  WARRANTY  OF  ANY KIND. THE AUTHOR
DISCLAIMS  ALL  WARRANTIES,  EITHER  EXPRESS  OR  IMPLIED,  INCLUDING  THE 
WARRANTIES  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. IN NO
EVENT  SHALL  THE  AUTHOR  OR  ITS  SUPPLIERS  BE  LIABLE  FOR ANY DAMAGES 
WHATSOEVER  INCLUDING  DIRECT,  INDIRECT,  INCIDENTAL, CONSEQUENTIAL, LOSS
OF BUSINESS  PROFITS  OR  SPECIAL  DAMAGES,  EVEN  IF  THE  AUTHOR  OR ITS 
SUPPLIERS  HAVE  BEEN   ADVISED  OF   THE  POSSIBILITY  OF  SUCH  DAMAGES.


--------------------------------------------------------------------------
-                                                                        -
-         *  *                 *              *          *               -        
-         ** ***   **   **     ***   **   ******     *** *  *            -        
-         *  *  * *  * *  *    *  * *  * *    *     *    * *             -        
-         *  *  * **** *  *    *  * *  *  **  *      **  ***             -        
-         *  *  * *    *  *    *  * *  *    * *        * * *             -        
-         ** *  *  ***  **   * *  *  **  ***  **  * ***  *  *            - 
-                                                                        -
--------------------------------------------------------------------------